#include "ddsLookup.h"

int highestRankLookup[8192];
holding_t topCardsLookup[14][8192];
