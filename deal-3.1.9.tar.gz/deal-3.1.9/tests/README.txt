The tests are in Tcl files with an initial prefix indicating the level of the test:

Level 1: Really simple one-line tests of basic functionality
Level 2: More complicated tests of basic functionality
Level 3: Simple tests of features included in lib, input, and format directories
Level 4: Complicated tests of features included in lib, input, and format directories
Level 5: ???
